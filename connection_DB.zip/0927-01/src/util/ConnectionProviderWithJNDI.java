package util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServlet;
import javax.sql.DataSource;

public class ConnectionProviderWithJNDI extends HttpServlet {
	@Resource(name = "jdbc/dataSource")
	private static DataSource dataSource;

//	@Override
//	public void init() throws ServletException {
//		try {
//			dataSource = (DataSource) new InitialContext()
//					.lookup("java:comp/etc/jdbc/dataSource");
//		} catch (NamingException e) {
//			e.printStackTrace();
//		}
//	}
	
	public static Connection getConnection() throws SQLException {
		return dataSource.getConnection();
	}
}
