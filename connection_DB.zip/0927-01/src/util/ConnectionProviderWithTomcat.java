package util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import org.apache.tomcat.jdbc.pool.DataSource;
import org.apache.tomcat.jdbc.pool.PoolProperties;

public class ConnectionProviderWithTomcat extends HttpServlet {
	private static DataSource dataSource;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("created datasource");
		PoolProperties p = new PoolProperties();
		p.setDriverClassName(config.getInitParameter("driverName"));
		p.setUrl(config.getInitParameter("url"));
		p.setUsername(config.getInitParameter("id"));
		p.setPassword(config.getInitParameter("password"));
		
		dataSource = new DataSource();
		dataSource.setPoolProperties(p);
	}
	
	public static Connection getConncetion() throws SQLException {
		return dataSource.getConnection();
	}
}
