package handler;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/errorHandler")
public class ErrorHandler extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println(req.getAttribute(RequestDispatcher.ERROR_STATUS_CODE));
		System.out.println(req.getAttribute(RequestDispatcher.ERROR_MESSAGE));
		System.out.println(req.getAttribute(RequestDispatcher.ERROR_REQUEST_URI));
		System.out.println(req.getAttribute(RequestDispatcher.ERROR_SERVLET_NAME));
		System.out.println(req.getAttribute(RequestDispatcher.ERROR_EXCEPTION));
		System.out.println(req.getAttribute(RequestDispatcher.ERROR_EXCEPTION_TYPE));
	}
}
