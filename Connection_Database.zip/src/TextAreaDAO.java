import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.xdevapi.Result;

// to get the details of database
class time_loadData {
	private int id;
	private String text;
	private LocalTime time;
	private boolean isAuto;

	public time_loadData() {
		
	}
	public time_loadData(int id, LocalTime time, boolean isAuto) {
		this.id = id;
		this.text = text;
		this.time = time;
		this.isAuto = isAuto;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public LocalTime getTime() {
		return time;
	}

	public void setTime(LocalTime time) {
		this.time = time;
	}

	public boolean isAuto() {
		return isAuto;
	}

	public void setAuto(boolean isAuto) {
		this.isAuto = isAuto;
	}

	@Override
	public String toString() {
		return "time_loadData [id=" + id + ", text=" + text + ", time=" + time + ", isAuto=" + isAuto + "]";
	}
}

public class TextAreaDAO {
	private String driver = "com.mysql.cj.jdbc.Driver"; // Driver 주소 적어두고 DriverManager로 connection 잡기 : 외부 라이브러리에서 jar
														// 가져오기
	private String url = "jdbc:mysql://localhost:3306/my_db"; // sql이랑 연결지을 connection data : url, id, password
	private String id = "root";
	private String password = "root";

	// 저장
	public int save(String text, LocalTime time, boolean isAuto) {
		String query = "INSERT INTO time_load (text, saveTime, isAuto) VALUES (?, ?, ?)";

		try (Connection conn = DriverManager.getConnection(url, id, password);
				PreparedStatement stmt = conn.prepareStatement(query);) {
			stmt.setString(1, text);
			stmt.setTime(2, Time.valueOf(time)); // sql Time 문으로 변형시켜줌
			stmt.setBoolean(3, isAuto);

			return stmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	// 로드
	public List<time_loadData> load() {
		String qurey = "SELECT id, text, saveTime, isAuto FROM time_load";
		List<time_loadData> list = new ArrayList<>();
		try (Connection conn = DriverManager.getConnection(url, id, password);
				PreparedStatement stmt = conn.prepareStatement(qurey);
				ResultSet rs = stmt.executeQuery()) {

			while (rs.next()) {
				int id = rs.getInt("id");
				String text = rs.getString("text");
				LocalTime time = rs.getTime("saveTime").toLocalTime(); // sql 로컬다임으로 변경 시켜주기
				boolean isAuto = rs.getBoolean("isAuto");

				time_loadData data = new time_loadData();
				data.setId(id);
				data.setTime(time);
				data.setAuto(isAuto);
				list.add(data);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	// 텍스트 값 불러오기
	public String load(int id) {
		String query = "SELECT text FROM time_load WHERE id = ?";
		
		try( Connection conn = DriverManager.getConnection(url, this.id, password);
				PreparedStatement stmt  =  conn.prepareStatement(query);){
					stmt.setInt(1,  id);
					
					try( ResultSet rs = stmt.executeQuery()){
						if(rs.next()) {
							return rs.getString("text");
						}
					}
				} catch(SQLException e) {
					e.printStackTrace();
				}
		return null;
	}
}
