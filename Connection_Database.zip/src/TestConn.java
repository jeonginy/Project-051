import java.time.LocalTime;
import java.util.List;

public class TestConn {
	public static void main(String[] args) {
		TextAreaDAO dao = new TextAreaDAO();
//		int result  =  dao.save("This is a test for database", LocalTime.now(), false);
//		int result  =  dao.save("This is a test for database2", LocalTime.now(), true);
//		System.out.println(result);
		
//		List<time_loadData> list = dao.load();
//		for(time_loadData data : list) {
//			System.out.println(data);
//		}
		String result = dao.load(3);
		System.out.println(result);
	}

}
