import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;

class TodayClock extends JFrame {
	private JLabel lblTime;
	public TodayClock() {
		Timer t = new Timer(1000, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				LocalDateTime now = LocalDateTime.now();
				lblTime.setText(now.toString());
			}
		});
		
		t.start();
		
		lblTime = new JLabel("get ready to start");
		add(lblTime);
		
		showGUI();
		
	}
	private void showGUI() {
		setSize(500,500);
		setLocation(300,100);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
	}
}
public class Main2 {
	public static void main(String[] args) {
		new TodayClock();
	}

}
