import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
class DataPanel extends JPanel {
	private int id;
	
		public int getId() {
		return id;
	}

		public DataPanel(time_loadData data) {
			id = data.getId();
			JLabel id = new JLabel(String.valueOf(this.id));
			String formatted = data.getTime().format(DateTimeFormatter.ofPattern("hh:mm:ss"));
			JLabel time = new JLabel(data.getTime().toString());
			JLabel isAuto = new JLabel(data.isAuto() ? "Auto_save" : "Non-Auto_save");
			
			add(id);
			add(time);
			add(isAuto);
			
			setBorder(BorderFactory.createLineBorder(Color.black));
			setPreferredSize(new Dimension(400, 70));
			
		}
}
public class ListDialog extends JDialog {
	TextAreaDAO dao;
	
	// id, LocalTime, isAuto 
	public ListDialog(AutoSave main) {
		dao = new TextAreaDAO();
		JTextArea txtArea = main.getTextArea();
		
		JPanel pnlCenter = new JPanel();
		pnlCenter.setLayout(new BoxLayout(pnlCenter, BoxLayout.Y_AXIS));
		
		MouseAdapter mouseAdapter = new MouseAdapter() {
			
			@Override
			public void mouseClicked(MouseEvent e) {
				DataPanel pnl = (DataPanel) e.getSource();
				int id = pnl.getId();
				System.out.println("Id User Clicked : " + id);
				
				String text = dao.load(id);
				txtArea.setText(text);
				
				dispose();
			}
		};
		
//		for each
		List<time_loadData> list = dao.load();
//		for( time_loadData d : list ) {
//			pnlCenter.add(new DataPanel(d));
//		}
		
//		for
		for(int i = 0; i < list.size(); i++) {
			DataPanel pnl = new DataPanel(list.get(i));
			pnl.addMouseListener(mouseAdapter);
			pnlCenter.add(pnl);
		}
		
//		pnlCenter.add(new DataPanel(new time_loadData(54, LocalTime.now(), false)));
//		pnlCenter.add(new DataPanel(new time_loadData(55, LocalTime.of(11, 30, 00), true)));
//		pnlCenter.add(new DataPanel(new time_loadData(57, LocalTime.of(10, 30, 00), false)));
		
		add(pnlCenter);
		showGUI();
		
	}

	private void showGUI() {
		pack();
//		setSize(400,400);
		setVisible(true);
	}
}












