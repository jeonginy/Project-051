import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.time.LocalTime;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.Timer;

class AutoSave extends JFrame implements ActionListener, ItemListener {
	private JButton savebtn;
	private JButton loadbtn;
	private JTextArea ta;
	private JCheckBox ck;
	private TextAreaDAO dao;
	private Timer timer;
	

//	add JTextArea for user to type text, 
//	then demonstrate the action saving what user write down into Database for every 5 seconds 
	
	public JTextArea getTextArea() {
		return ta;
	}
	
	public AutoSave() {
		dao = new TextAreaDAO();
		timer = new Timer(1000 * 60, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				dao.save(ta.getText(), LocalTime.now(), true);
			}
		});
		savebtn = new JButton("Save");
		loadbtn = new JButton("Load");
		
		savebtn.addActionListener(this);
		loadbtn.addActionListener(this);	
		
		JPanel pnl = new JPanel();
		setTitle("Type any text");
		pnl.add(savebtn);
		pnl.add(loadbtn);
		
		ta = new JTextArea();
		JScrollPane scrl = new JScrollPane(ta);
		
		ck = new JCheckBox("Auto_Save");
		ck.addItemListener(this);
		
	
		add(pnl, "North");
		add(scrl);
		add(ck, "South");
		
		showGUI();
	
	}

	private void showGUI() {
		setSize(500, 500);
		setLocation(300, 100);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == savebtn) {
			int result = dao.save(ta.getText(), LocalTime.now(), false);
			if(result == 1) {
				JOptionPane.showMessageDialog(this, "saved completely");
			} 
		} else if( e.getSource() == loadbtn) {
			new ListDialog(this);
		}
	}
	@Override
	public void itemStateChanged(ItemEvent e) {
//		System.out.println(e.getStateChange());
		if( e.getStateChange() == ItemEvent.SELECTED) {
			System.out.println("saved automatically");
			timer.start();
		} else if(e.getStateChange() == ItemEvent.DESELECTED) {
			timer.stop();
		}
	}


}

public class Main4 {
	public static void main(String[] args) {
		new AutoSave();
//		new ListDialog();
	}

}
