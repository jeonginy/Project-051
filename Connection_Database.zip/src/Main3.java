import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;

class AutoClosing extends JFrame {
	public AutoClosing() {	
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				JDialog dialog = new JDialog(AutoClosing.this, "Count - Down");
				JLabel lbl = new JLabel("5");
				dialog.add(lbl);
				dialog.setModal(true);
				dialog.pack();
				dialog.setLocationRelativeTo(AutoClosing.this);
						//	1000 milliseconds : 1 sec
				Timer t = new Timer(1000, new ActionListener() {
					private int count  = 5;
					@Override
					public void actionPerformed(ActionEvent e) {
						if( count == 0 ) {
							System.exit(0);
						} 
						count--;
						lbl.setText(String.valueOf(count));
					}
				});
				t.setInitialDelay(1000);	//  after one second, starts action
				t.start();
				
				dialog.setVisible(true);
			}
		});
		
		showGUI();
	}

	private void showGUI() {
		setSize(500,500);
		setLocation(300,100);
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);	 
		setVisible(true);
	}
	
	
}
public class Main3 {

	public static void main(String[] args) {
		new AutoClosing();
	}

}
